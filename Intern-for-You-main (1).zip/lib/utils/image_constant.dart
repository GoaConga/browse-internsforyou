class ImageConstant {
  static String kImgJohnSmith = 'assets/images/john_smith.png';
  static String kImgWA = 'assets/images/wa_app_logo.png';
  static String imgSliderbar = 'assets/images/img_sliderbar.svg';
  static String kImgIntern = 'assets/images/intern.png';
  static String kImgCroppedWA = 'assets/images/cropped_wa.png';
  static String imgArrow1 = 'assets/images/img_arrow1.svg';
  static String imgSliderbar2 = 'assets/images/img_sliderbar_2.svg';
  static String imgSliderbar1 = 'assets/images/img_sliderbar_1.svg';
  static String kImgCompany = 'assets/images/company.png';
  static String kImgNotFound = 'assets/images/not_found.png';
}
