# Update (17/05/2022)  

## Theme
> Theme / Styling has been updated to support input fields, profile buttons and more.  

## Widgets
> Added the widgets I've made to the 'temp_widgets' folder, can be moved elsewhere depending on where they're needed. Just there for access sake.