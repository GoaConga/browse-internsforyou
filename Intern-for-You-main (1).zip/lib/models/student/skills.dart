// This had to go somewhere so I decided to put it in the students folder
class Skills {
  late String skillName;
  late int skillProficiency;

  Skills({
    this.skillName = '',
    this.skillProficiency = 0,
  });
}
