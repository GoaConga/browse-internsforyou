class SocialMedia {
  late String linkedIn;
  late String gitHub;
  late List<String> other;
}
