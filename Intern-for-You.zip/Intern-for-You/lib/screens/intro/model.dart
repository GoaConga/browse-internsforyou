import 'package:get/get.dart';

class IntroItemModel {}

class IntroModel {
  RxList<IntroItemModel> introItemModelList = RxList.filled(1, IntroItemModel());
}
