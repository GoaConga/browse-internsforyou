import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:internsforyou/screens/register/controller.dart';
import 'package:internsforyou/theme/ify_custom_theme.dart';
import 'package:internsforyou/utils/routes/app_routes.dart';
import 'package:internsforyou/setup/internship/internship_main.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';

import '../widgets/ify_textfields.dart';

class RegisterScreen extends GetView<RegisterController> {
  RegisterScreen({Key? key}) : super(key: key);

  final bool isCompamy = true;
  final _formKey = GlobalKey<FormState>();
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController password2Controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Center(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 10, 20, 5),
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Column(
                    children: [
                      Text(
                          '${isCompamy ? 'Company' : 'Personal'} Account Details',
                          style: IFYFonts.introHeader),
                      Container()
                    ],
                  ),
                  Column(
                    children: [
                      Padding(
                          padding: const EdgeInsets.fromLTRB(40, 10, 40, 2),
                          child: primaryTextField(
                              '${isCompamy ? 'company' : 'personal'} email address',
                              'example@mail.com',
                              false,
                              emailController,
                              TextInputType.emailAddress,
                              1,
                              30)),
                      Padding(
                          padding: const EdgeInsets.fromLTRB(40, 10, 40, 2),
                          child: primaryTextField(
                              'password',
                              'password',
                              true,
                              passwordController,
                              TextInputType.visiblePassword,
                              1,
                              30)),
                      Padding(
                          padding: const EdgeInsets.fromLTRB(40, 10, 40, 2),
                          child: primaryTextField(
                              're-type password',
                              'password',
                              true,
                              password2Controller,
                              TextInputType.visiblePassword,
                              1,
                              30)),
                    ],
                  ),
                  Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(bottom: 5),
                        child: ElevatedButton(
                          child: const Text('Create Account'),
                          style: IFYButtons.primaryButton,
                          onPressed: () {
                            Get.toNamed(AppRoutes.registerScreen);
                            if (_formKey.currentState!.validate()) {
                              debugPrint(
                                  "Username: ${emailController.text}\nPassword: ${passwordController.text}");
                              //TODO: Continue if passed
                              Get.toNamed(AppRoutes.detailsFormScreen);
                            } else {
                              debugPrint('false');
                            }
                          },
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void doUserRegistration() async {
    final username = emailController.text.trim();
    final email = emailController.text.trim();
    final password = passwordController.text.trim();

    final user = ParseUser.createUser(username, password, email);

    var response = await user.signUp();

    // if (response.success) {
    //   showSuccess();
    // } else {
    //   showError(response.error!.message);
    // }
  }

  // void showSuccess() {
  //   showDialog(
  //     context: context,
  //     builder: (BuildContext context) {
  //       return AlertDialog(
  //         title: const Text("Success!"),
  //         content: const Text("User was successfully created!"),
  //         actions: <Widget>[
  //           new FlatButton(
  //             child: const Text("OK"),
  //             onPressed: () {
  //               Navigator.push(
  //                 context,
  //                 MaterialPageRoute(builder: (context) => SecondRoute()),
  //               );
  //             },
  //           ),
  //         ],
  //       );
  //     },
  //   );
  // }

  // void showError(String errorMessage) {
  //   showDialog(
  //     context: context,
  //     builder: (BuildContext context) {
  //       return AlertDialog(
  //         title: const Text("Error!"),
  //         content: Text(errorMessage),
  //         actions: <Widget>[
  //           new FlatButton(
  //             child: const Text("OK"),
  //             onPressed: () {
  //               Navigator.of(context).pop();
  //             },
  //           ),
  //         ],
  //       );
  //     },
  //   );
  // }
}
