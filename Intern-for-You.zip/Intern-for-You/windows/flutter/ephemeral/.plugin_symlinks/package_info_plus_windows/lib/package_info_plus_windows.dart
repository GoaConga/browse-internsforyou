export 'src/package_info_plus_windows.dart';
